
<?php $__env->startSection('title'); ?>
    Exercise
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="courses-area-style " style="padding: 150px 0px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <?php if(!empty($exercise)): ?>
                       <div class="embed-responsive embed-responsive-16by9">
                        <?php if($exercise->type == 0): ?> 
                            <iframe class="embed-responsive-item" src="https://flat.io/embed/<?php echo e($exercise->code); ?>"></iframe> 
                        <?php else: ?>
                            <iframe class="embed-responsive-item" src="https://sibl.pub/<?php echo e($exercise->code); ?>"></iframe> 
                        <?php endif; ?>
                        </div>
                    <?php else: ?>
                        Not found! try again
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\music-website\resources\views/pages/step/viewer.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title'); ?>
    Exercise
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 <section class="courses-area-style " style="padding: 150px 0px;">
        <div class="container">
            <div class="showing-result">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-md-4">
                        <div class="showing-result-count">
                            <h4> <b>Step 1 - Choose the Book You are Using:</b></h4>
							<form id="rendered-form"><div class="rendered-form"><div class=""><h1 access="false" id="control-5054511">Choose a Book</h1></div><div class="formbuilder-select form-group field-select-1608522572807"><label for="select-1608522572807" class="formbuilder-select-label">Select</label><select class="form-control" name="select-1608522572807" id="select-1608522572807"><option value="option-1" selected="true" id="select-1608522572807-0">Sound Fundamentals Book 1</option><option value="option-2" id="select-1608522572807-1">Sound Fundamentals Book 2</option></select></div><input type="hidden" name="hidden-1608522699438" value="ID_Book" access="false" id="hidden-1608522699438"><div class="formbuilder-button form-group field-button-1608522652263"><button type="button" class="btn-default btn" name="button-1608522652263" access="false" style="default" id="button-1608522652263">Submit</button></div></div></form>
					<div class="row">
                <div class="col-lg-3 col-sm-6">
                    <div class="single-affordable one">
                        <i class="">
                            <img src="assets/img/coverBook1.png" alt="">
                       </i>

                        <h3>Sound Fundamentals Book 1</h3>
                    </div>
                </div>

                <div class="col-lg-3 col-sm-6">
                    <div class="single-affordable two">
                        <i class="">
                            <img src="assets/img/coverBook2.png" alt="">
                        </i>
                        <h3>Sound Fundamentals Book 2</h3>
                    </div>
                </div> 
                </div>  
                </div>
            </div> 
        </div>
    </section>
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\music-website\resources\views/pages/exercise/exercise.blade.php ENDPATH**/ ?>
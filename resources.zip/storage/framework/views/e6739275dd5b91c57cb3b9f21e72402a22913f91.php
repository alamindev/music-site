
    <!-- Start Footer Top Area -->
    <footer class="footer-top-area">
        <div class="container footer-inner">
            <div class="row">
                <div class="col-lg-4 col-sm-6">
                    <div class="footer-widget">
                        <h3>Find Us</h3>

                        <ul class="address">
                           <?php if(!empty($address) &&  $address->address_datas != ''): ?>
                                <?php
                                $address_datas = json_decode($address->address_datas); 
                                ?>
                                    <?php $__currentLoopData = $address_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <?php
                                            $da = explode('|##|', $datas) 
                                            ?>
                                             <li class="location">
                                                <i class="<?php echo e($da[0]); ?>"></i> <?php echo e($da[1]); ?> 
                                            </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?> 
                            <li>Data not found!</li>
                             <?php endif; ?> 
                        </ul>
                    </div>
                </div>

                <div class="col-lg-4 col-sm-6">
                    <div class="footer-widget">
                        <h3>Useful links</h3>

                        <ul class="link">
                          <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($page->type == 'footer'): ?>
                                <li>
                                    <a href="<?php echo e(route('page', $page->slug)); ?>">
                                        <?php echo e($page->title); ?>

                                    </a>
                                </li> 
                                <?php else: ?>
                                    not found!
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </ul>
                    </div>
                </div>

                <div class="col-lg-4 col-sm-6">
                    <div class="footer-widget">
                        <h3>Follow Us</h3>

                        <ul class="link">
                          <?php if(!empty($address) && $address->social_datas != ""): ?> 
                                            <?php
                                             $socials = json_decode($address->social_datas); 
                                            ?>
                                                <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                              <li><a href="<?php echo e($data); ?>"><?php echo e($key); ?></a></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                            <li>Data not found!</li>
                             <?php endif; ?>  
                        </ul>
                    </div>
                </div>


            </div>
        </div>
    </footer>
    <!-- End Footer Top Area --><?php /**PATH D:\XAMPP\htdocs\music-website\resources\views/layouts/footer.blade.php ENDPATH**/ ?>
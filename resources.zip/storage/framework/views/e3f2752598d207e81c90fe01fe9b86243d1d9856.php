
<?php $__env->startSection('title'); ?>
    Exercise
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <section class="courses-area-style " style="padding: 150px 0px;">
        <div class="container">
            <div class="showing-result">
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <div class="showing-result-count">
                            <h4> <b>Step 3 - Select Your Exercise:</b></h4>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <?php $__currentLoopData = $exercises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exercise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-6 col-12">
                        <div class="single-course lessons-img-box">
                            <a href="<?php echo e(route('step.viewer',['exercise_id' => $exercise->id, 'instrument_id' => $exercise->horn_id, 'book_id' => $exercise->book_id])); ?>">
                                <img src="<?php echo e(asset('images/floating.png')); ?>" alt="Image">
                                <div class="course-content" style="border: none;">
                                    <span class="tag pt-2"><?php echo e($exercise->exercise_name); ?> </span>
                                </div>
                            </a>
                        </div>
                    </div> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\music-website\resources\views/pages/step/exercise.blade.php ENDPATH**/ ?>
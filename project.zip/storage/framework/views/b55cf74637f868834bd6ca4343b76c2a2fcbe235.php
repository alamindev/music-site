

<?php $__env->startSection('title'); ?>
    URL list
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <link href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css" rel="stylesheet"> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="row"> 
  <div class="col-lg-12">
   <div class="card"> 
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3>   List of url   </h3>
        <a class="btn btn-primary" href="<?php echo e(route('url.add')); ?>">Add New Url</a>
    </div>
        <div class="card-body card-block">
             <table class="table table-bordered yajra-datatable" id="datatable">
        <thead>
            <tr>
                <th>No</th>
                <th>URL</th>  
                <th>Instrument Name</th>  
                <th>Exercise Name</th>  
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
        </div> 
    </div>
  </div>
  </div>
</div>
  <div class="modal fade" id="update" tabindex="-1" role="dialog" aria-labelledby="smallmodalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md" role="document">
            <div class="modal-content">
             <form id="update-url" action="" method="post"   class="form-horizontal"> 
                <?php echo csrf_field(); ?> 
                <div class="modal-header d-flex">
                    <h5 class="modal-title" id="smallmodalLabel">Update URL</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body"> 
                    <div class="form-group">
                    <label for="url" class=" form-control-label">URL Name <span class="text-danger">*</span></label>
                        <textarea name="url" id="url" cols="30" rows="3" class="url form-control"></textarea> 
                    <?php if($errors->has('url')): ?>
                        <div class="text-danger"><?php echo e($errors->first('url')); ?></div>
                    <?php endif; ?>   
                </div>  
                <div class="form-group">
                    <label for="instrument_id" class=" form-control-label">Instrument <span class="text-danger">*</span></label>
                    <select name="instrument_id" id="instrument_id"  data-placeholder="Please select instrument..." class="update-select-instrument form-control-sm form-control standardSelect">
                        <option value="" label="default"></option> 
                        <?php $__currentLoopData = $horns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $horn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                          <option value="<?php echo e($horn->id); ?>"><?php echo e($horn->horn_name); ?></option> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                      <?php if($errors->has('instrument_id')): ?>
                        <div class="text-danger"><?php echo e($errors->first('instrument_id')); ?></div>
                    <?php endif; ?>   
                </div> 
                <div class="form-group">
                    <label for="exercise_id" class=" form-control-label">Exercise <span class="text-danger">*</span></label>
                    <select name="exercise_id" id="exercise_id" data-placeholder="Please select exercise..." class="update-select-exercise form-control-sm form-control standardSelect">
                        <option value="" label="default"> </option> 
                        <?php $__currentLoopData = $exercises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exercise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                          <option value="<?php echo e($exercise->id); ?>"><?php echo e($exercise->exercise_name); ?></option> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                      <?php if($errors->has('exercise_id')): ?>
                        <div class="text-danger"><?php echo e($errors->first('exercise_id')); ?></div>
                    <?php endif; ?>   
                </div> 
                </div>
                <div class="modal-footer">
                      <button type="Submit" class="btn btn-primary">Update</button>
                </div>
                </form>
            </div>
        </div>
    </div>
  <div class="modal fade" id="view" tabindex="-1" role="dialog" aria-labelledby="smallmodalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header d-flex">
                    <h5 class="modal-title" id="smallmodalLabel">View Data</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
              <div class="modal-body">
                <div class="py-3">
                    <strong>Url: </strong> <span class="view_url " style="word-wrap: break-word;"></span>
                </div>
                <div class="py-3">
                    <strong>Instrument Name:</strong> <span class="view_instrument"></span>
                </div>
                <div class="py-3">
                    <strong>Exercise Name:</strong> <span class="view_exercise"></span>
                </div>
              </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?> 
 
<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script> 
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>  
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"></script>
<script> 
    $(function () {
     $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    var table = $('#datatable').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('url')); ?>",
        columns: [
            {data: 'DT_RowIndex', name: 'DT_RowIndex'}, 
            {data: 'url', name: 'url'},  
              {data: 'instrument_name', name: 'instrument_name'}, 
              {data: 'exercise_name', name: 'exercise_name'}, 
            {
                data: 'action', 
                name: 'action', 
                orderable: true, 
                searchable: true
            },
        ]
    });
    $('#datatable').on('click', '.delete', function (e) {  
    Swal.fire({
            title: 'Are you sure?',
            text: 'You will not be able to recover this Data!',
            type: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, keep it'
            }).then((result) => {
                if (result.value) { 
                    e.preventDefault();
                        var url = $(this).data('remote');  
                        $.ajax({
                            url:url ,
                            type: 'DELETE',
                            dataType: 'json',
                            data: {method: '_DELETE', submit: true}
                        }).always(function (data) {
                            if(data.message == 'error'){
                            Swal.fire(
                                'Error!',
                                'Something went wrong',
                                'error'
                                )
                            }else{
                                Swal.fire(
                                'Deleted!',
                                'Your Data has been deleted.',
                                'success'
                                ) 
                            $('#datatable').DataTable().draw(false);
                            }
                            
                        });
                } else if (result.dismiss === Swal.DismissReason.cancel) {
                    Swal.fire(
                    'Cancelled',
                    'Your Data file is safe :)',
                    'error'
                    )
                }
            }) 
    }); 
    $('#datatable').on('click', '.edit', function (e) {   
     var url = $(this).data('remote');  
     var update = $(this).data('remote-update');  
    $.ajax({
        url:url ,
        type: 'GET',
        dataType: 'json',
        data: {method: '_GET'}
    }).always(function (data) {
        if(data.message == 'success'){ 
            $('#update').modal('show'); 
            $('#update-url').attr('action', update) 
            $('.url').val(data.data.url)
            $('.update-select-instrument').val(data.data.horn.id).change();
            $('.update-select-exercise').val(data.data.exercise.id).change();
              
        } 
    });
    }); 
    $('#datatable').on('click', '.view', function (e) {   
     var url = $(this).data('remote');  
     var update = $(this).data('remote-update');  
    $.ajax({
        url:url ,
        type: 'GET',
        dataType: 'json',
        data: {method: '_GET'}
    }).always(function (data) {
        if(data.message == 'success'){ 
            $('#view').modal('show');  
            $('.view_url').text(data.data.url)
            $('.view_instrument').text(data.data.horn.horn_name);
            $('.view_exercise').text(data.data.exercise.exercise_name); 
        } 
    });
    }); 

  }); 
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\music-website\resources\views/admin/pages/url/url.blade.php ENDPATH**/ ?>
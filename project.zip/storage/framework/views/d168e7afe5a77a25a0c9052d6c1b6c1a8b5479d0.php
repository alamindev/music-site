
<?php $__env->startSection('title'); ?>
    Exercise
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 <section class="courses-area-style " style="padding: 150px 0px;"> 
    <div class="container">
    <?php if(Session::has('success')): ?> 
        <div class="alert alert-success">
            <?php echo e(Session::get('success')); ?>

        </div> 
        <?php endif; ?>
        <div class="row align-items-center">
            <div class="col-lg-6 col-md-4">
                <div class="showing-result-count">
                    <h4> <b>Step 1 - Choose the Book You are Using:</b></h4>
                    <form id="rendered-form" method="get" action="" class="py-2"> 
                        <h1 access="false" id="control-5054511">Choose a Book</h1> 
                        <div class="wrapper">
                            <select class="form-control book_name" name="book_id">
                                <option value="">Choose a Book</option>
                                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                    <option data-remote="<?php echo e(route('step.instrument',[$book->id])); ?>" value="<?php echo e($book->id); ?>"><?php echo e($book->name); ?></option> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </form> 
                </div>
                  <div class="row pt-4 w-100">
                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <div class="col-lg-3 col-sm-6">
                        <div class="single-affordable one">
                            <i class="">
                                <img   src="<?php echo e(url('storage'.  $book->image)); ?>" alt="<?php echo e($book->name); ?>"> 
                            </i> 
                            <h3><?php echo e($book->name); ?></h3>
                        </div>
                    </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>  
            </div> 
        </div>
    </div> 
</section>
<?php $__env->stopSection(); ?>  

<?php $__env->startSection('script'); ?>
    <script>
        $(function(){
            $(".book_name").on("change", function(e) { 
               if($(this).find(":selected").val() != ''){
                    var url = $(this).find(":selected").attr('data-remote')
                    let form = $(this).closest('form');
                    form.attr('action',url) 
                    form.submit();
                } 
            });
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\music-website\resources\views/pages/step/book.blade.php ENDPATH**/ ?>
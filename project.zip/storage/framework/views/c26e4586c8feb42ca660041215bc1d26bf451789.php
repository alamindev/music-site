<!-- Start Preloader Area -->
    <div class="loader-wrapper">
        <div class="loader">
            <div class="dot-wrap">
                <span class="dot"></span>
                <span class="dot"></span>
                <span class="dot"></span>
                <span class="dot"></span>
            </div>
        </div>
    </div>
    <!-- End Preloader Area -->

    <!-- Start Navbar Area -->
    <div class="navbar-area navbar-area-two">
        <!-- Menu For Mobile Device -->
        <div class="mobile-nav">
            <a href="<?php echo e(route('index')); ?>" class="logo">
                <?php if($setting->site_logo != null): ?>
                <img width="130" src="<?php echo e(url('storage'. $setting->site_logo)); ?>" alt="Logo">
                <?php else: ?>
                Logo
                <?php endif; ?>
            </a>
            <?php if(auth()->guard()->check()): ?> 
                <div class="header-menu d-block d-lg-none" style="z-index: 999;position: absolute;right: 60px;top: 15px;"> 
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle active" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <?php if(auth()->user()->photo == null): ?>
                                <img class="user-avatar rounded-circle" width="40" src="<?php echo e(asset('assets/images/admin.jpg')); ?>" alt="User Avatar"> 
                            <?php else: ?>
                                <img class="user-avatar rounded-circle" width="40" src="<?php echo e(url('storage'. auth()->user()->photo)); ?>" alt="User Avatar"> 
                            <?php endif; ?>
                        </a>

                        <div class="user-menu dropdown-menu">
                            <a class="nav-link" href="<?php echo e(route('profile')); ?>">My Profile</a> 
                                <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                                        <i class="fa fa-power -off"></i>
                                        <?php echo e(__('Logout')); ?>

                                        </a>  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                        </form> 
                        </div>
                    </div> 
                </div>
            <?php endif; ?> 
        </div>

        <!-- Menu For Desktop Device -->
        <div class="main-nav">
            <div class="container-fluid">
                <nav class="navbar navbar-expand-md">
                      <a href="<?php echo e(route('index')); ?>" class="logo">
                        <?php if($setting->site_logo != null): ?>
                            <img width="120" src="<?php echo e(url('storage'. $setting->site_logo)); ?>" alt="Logo">
                            <?php else: ?>
                            Logo
                            <?php endif; ?>
                        </a>

                    <div class="collapse navbar-collapse mean-menu">
                        <ul class="navbar-nav ml-auto mr-3">
                            <li class="nav-item">
                                <a href="<?php echo e(route('index')); ?>" class="nav-link">
									Home
								</a>
                            </li> 
                            <li class="nav-item">
                                <a href="<?php echo e(route('step.book')); ?>" class="nav-link">
									Choose Exercises
								</a>
                            </li> 
                                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($page->type == 'header'): ?>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('page', $page->slug)); ?>" class="nav-link">
                                            <?php echo e($page->title); ?>

                                        </a>
                                    </li> 
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('login')); ?>" class="nav-link">
									Login
								</a>
                            </li>  
                            <?php endif; ?>
                        </ul>
 
                        <?php if(auth()->guard()->guest()): ?>
                        <div class="others-option">
                            <div class="register">
                                <a href="<?php echo e(route('register')); ?>" class="default-btn desktop-login-btn">
									Register Now
								</a>
                            </div>
                        </div> 

                        <?php endif; ?>
                        <?php if(auth()->guard()->check()): ?> 
                             <div class="header-menu d-none d-lg-block"> 
                            <div class="user-area dropdown float-right">
                                <a href="#" class="dropdown-toggle active" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                      <?php if(auth()->user()->photo == null): ?>
                                        <img class="user-avatar rounded-circle" width="40" src="<?php echo e(asset('assets/images/admin.jpg')); ?>" alt="User Avatar"> 
                                    <?php else: ?>
                                        <img class="user-avatar rounded-circle" width="40" src="<?php echo e(url('storage'. auth()->user()->photo)); ?>" alt="User Avatar"> 
                                    <?php endif; ?>
                                </a>

                                <div class="user-menu dropdown-menu">
                                    <a class="nav-link" href="<?php echo e(route('profile')); ?>">My Profile</a> 
                                      <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();">
                                                <i class="fa fa-power -off"></i>
                                                <?php echo e(__('Logout')); ?>

                                                </a>  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                                    <?php echo csrf_field(); ?>
                                                </form> 
                                </div>
                            </div>

                        </div>
                        <?php endif; ?>
                    </div>
                </nav>
            </div>
        </div> 
         
      <!-- Start Others Option For Responsive -->
        <div class="others-option-for-responsive"> 
            <?php if(auth()->guard()->guest()): ?>
                <div class="container">
                <div class="dot-menu">
                    <div class="inner">
                        <div class="circle circle-one"></div>
                        <div class="circle circle-two"></div>
                        <div class="circle circle-three"></div>
                    </div>
                </div>

                <div class="container">
                    <div class="option-inner">
                        <div class="others-option justify-content-center d-flex align-items-center">

                            <div class="register">
                                <a href="<?php echo e(route('register')); ?>" class="default-btn">
										Register Now
									</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <!-- End Others Option For Responsive -->
    </div> <?php /**PATH D:\XAMPP\htdocs\music-website\resources\views/layouts/header.blade.php ENDPATH**/ ?>
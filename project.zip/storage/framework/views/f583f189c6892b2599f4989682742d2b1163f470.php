<?php $__env->startSection('title'); ?>
    password reset
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="user-area-style" style="padding: 150px 0px 50px;">
        <section class="user-area-style recover-password-area">
            <div class="container">
                <div class="contact-form-action recover">
                    <div class="form-heading text-center">
                        <h3 class="form-title">Enter New Password!</h3>
                        <p class="reset-desc">Reset the password.</a>
                        </p>
                    </div>
   <?php if(Session::has('message')): ?>
                        <div class="alert alert-danger"><?php echo e(Session::get('message')); ?></div>
                    <?php endif; ?>
                    <form method="post" action="<?php echo e(route('reset')); ?>">
                    <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input id="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" name="password"  required autocomplete="new-password">
                                      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 <?php if(Session::has('phone')): ?>
                                    <input type="hidden" name="phone" value="<?php echo e(Session::get('phone')); ?>">
                                <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                  <label for="password-confirm">Confirm Password</label>
                                    <input id="password-confirm" required class="form-control" type="password" name="password_confirmation"  required autocomplete="new-password"> 
                                </div>
                            </div>
  
                            <div class="col-12">
                                <button class="default-btn btn-two" type="submit">
									Submit
								</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\music-website\resources\views/auth/passwords/reset.blade.php ENDPATH**/ ?>
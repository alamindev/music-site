

<?php $__env->startSection('title'); ?>
    URL list
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <link href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css" rel="stylesheet"> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="row">
  <div class="col-lg-12">
     <div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h3>  Add new url   </h3>
        <a class="btn btn-info" href="<?php echo e(route('url')); ?>">Back</a>
    </div>
        <div class="card-body card-block">
            <form action="<?php echo e(route('url.store')); ?>" method="post"   class="form-horizontal"> 
                <?php echo csrf_field(); ?> 
                <div class="form-group">
                    <label for="url" class=" form-control-label">URL Name <span class="text-danger">*</span></label>
                        <textarea name="url" id="url" cols="30" rows="3" class="form-control"></textarea> 
                    <?php if($errors->has('url')): ?>
                        <div class="text-danger"><?php echo e($errors->first('url')); ?></div>
                    <?php endif; ?>   
                </div>  
                <div class="form-group">
                    <label for="instrument_id" class=" form-control-label">Instrument<span class="text-danger">*</span></label>
                    <select name="instrument_id" data-placeholder="Please select instrument..." id="instrument_id" class="form-control-sm form-control standardSelect">
                        <option value="" label="default"></option> 
                        <?php $__currentLoopData = $horns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $horn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                          <option value="<?php echo e($horn->id); ?>"><?php echo e($horn->horn_name); ?></option> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                      <?php if($errors->has('instrument_id')): ?>
                        <div class="text-danger"><?php echo e($errors->first('instrument_id')); ?></div>
                    <?php endif; ?>   
                </div> 
                <div class="form-group">
                    <label for="exercise_id" class=" form-control-label">Exercise <span class="text-danger">*</span></label>
                    <select name="exercise_id" data-placeholder="Please select exercise..." id="exercise_id" class="form-control-sm form-control standardSelect">
                        <option value="" label="default"></option> 
                        <?php $__currentLoopData = $exercises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exercise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                          <option value="<?php echo e($exercise->id); ?>"><?php echo e($exercise->exercise_name); ?></option> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                      <?php if($errors->has('exercise_id')): ?>
                        <div class="text-danger"><?php echo e($errors->first('exercise_id')); ?></div>
                    <?php endif; ?>   
                </div> 
                <div class="p-2">
                    <button type="submit" class="btn btn-success btn-sm">
                       <i class="fa fa-plus"></i> Save
                    </button> 
                </div>
            </form>
        </div> 
    </div>
  </div> 
  </div>
</div>
  
<?php $__env->stopSection(); ?>
 <?php $__env->startPush('script'); ?>   
       <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"></script>
       <script>
          jQuery(".standardSelect").chosen({
                disable_search_threshold: 10,
                no_results_text: "Oops, nothing found!",
                width: "100%"
            });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\music-website\resources\views/admin/pages/url/add-url.blade.php ENDPATH**/ ?>
<aside id="left-panel" class="left-panel">
    <nav class="navbar navbar-expand-sm navbar-default">
        <div id="main-menu" class="main-menu collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li class="<?php echo e(Route::is('admin.home') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.home')); ?>"><i class="menu-icon fa fa-dashboard"></i> Dashboard </a>
                </li> 
                <li class="<?php echo e(Route::is('book') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('book')); ?>"><i class="menu-icon fa fa-book"></i> Books </a>
                </li> 
                <li class="<?php echo e(Route::is('instrument') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('instrument')); ?>"><i class="menu-icon fa fa-bullseye"></i> Instruments </a>
                </li> 
                <li class="<?php echo e(Route::is('exercise') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('exercise')); ?>"><i class="menu-icon fa fa-eercast"></i> Exercise </a>
                </li> 
                <li class="<?php echo e(Route::is('url') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('url')); ?>"><i class="menu-icon fa fa-plus"></i> Add URL </a>
                </li> 
                <li class="<?php echo e(Route::is('banner') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('banner')); ?>"><i class="menu-icon fa fa-bandcamp"></i> Banner </a>
                </li>  
                 <li class="<?php echo e((Route::is('pages') || Route::is('page.create')) ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('pages')); ?>"><i class="menu-icon fa fa-address-book-o "></i> Pages </a>
                </li>
                <li class="<?php echo e(Route::is('socialinfos') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('socialinfos')); ?>"><i class="menu-icon fa fa-share-square-o "></i> Social & address </a>
                </li> 
                <li class="<?php echo e(Route::is('setting') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('setting')); ?>"><i class="menu-icon fa fa-cogs"></i> Setting </a>
                </li>   
                
            </ul>
        </div> 
    </nav>
</aside><?php /**PATH D:\XAMPP\htdocs\music-website\resources\views/admin/partials/sidebar.blade.php ENDPATH**/ ?>
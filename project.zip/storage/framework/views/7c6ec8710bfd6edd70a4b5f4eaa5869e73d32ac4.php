

<?php $__env->startSection('title'); ?>
  add    Exercise  
<?php $__env->stopSection(); ?> 
<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="row">
  <div class="col-lg-12">
     <div class="card">
     <div class="card-header d-flex justify-content-between align-items-center">
        <h3>  Add new exercise   </h3>
        <a class="btn btn-info" href="<?php echo e(route('exercise')); ?>">Back</a>
    </div> 
        <div class="card-body card-block">
            <form action="<?php echo e(route('exercise.store')); ?>" method="post"   class="form-horizontal"> 
                <?php echo csrf_field(); ?> 
                <div class="form-group">
                    <label for="exercise_name" class=" form-control-label">Exercise Name <span class="text-danger">*</span></label>
                        <input type="text" id="exercise_name" name="exercise_name" class="form-control" placeholder="Exercise name"> 
                    <?php if($errors->has('exercise_name')): ?>
                        <div class="text-danger"><?php echo e($errors->first('exercise_name')); ?></div>
                    <?php endif; ?>   
                </div>  
                <div class="form-group">
                    <label for="book_id" class=" form-control-label">Book ID <span class="text-danger">*</span></label>
                    <select name="book_id" id="book_id" class="form-control-sm form-control">
                        <option value="">Please select book</option> 
                        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                          <option value="<?php echo e($book->id); ?>"><?php echo e($book->name); ?></option> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                      <?php if($errors->has('book_id')): ?>
                        <div class="text-danger"><?php echo e($errors->first('book_id')); ?></div>
                    <?php endif; ?>   
                </div> 
                <div class="p-2">
                    <button type="submit" class="btn btn-success btn-sm">
                       <i class="fa fa-plus"></i> Save
                    </button> 
                </div>
            </form>
        </div> 
    </div>
  </div> 
  </div>
</div>
 
<?php $__env->stopSection(); ?>
 <?php $__env->startPush('script'); ?>   
       <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\music-website\resources\views/admin/pages/exercise/add-exercise.blade.php ENDPATH**/ ?>
 

<?php $__env->startSection('title'); ?>
   Update page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('assets/css/lib/chosen/chosen.css')); ?>" rel="stylesheet"> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <form action="<?php echo e(route('page.update', $edit->id)); ?>" method="post"  enctype="multipart/form-data" class="form-horizontal"> 
        <?php echo csrf_field(); ?> 
       <div class="row">  
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">
                       Page
                    </div>
                    <div class="card-body card-block"> 
                        <div class="form-group">
                            <label for="title" class=" form-control-label">Title <span class="text-danger">*</span></label>
                            <input type="text" required id="title" name="title" value="<?php echo e($edit->title); ?>" class="form-control" placeholder="Enter service title"> 
                            <?php if($errors->has('title')): ?>
                                <div class="text-danger"><?php echo e($errors->first('title')); ?></div>
                            <?php endif; ?>   
                        </div>      
                        <div class="form-group">
                            <label for="type" class=" form-control-label">Select Position <span class="text-danger">*</span></label>
                           <select required data-placeholder="Choose Position" name="type" id="type" class="form-control">
                               <option value="" ></option> 
                               <option value="header" <?php if($edit->type == 'header'): ?> selected <?php endif; ?> >Top Header</option> 
                               <option value="footer" <?php if($edit->type == 'footer'): ?> selected <?php endif; ?>>Footer</option> 
                           </select>
                            <?php if($errors->has('type')): ?>
                                <div class="text-danger"><?php echo e($errors->first('type')); ?></div>
                            <?php endif; ?>   
                        </div>         
                        <div class="form-group">
                            <label for="content" class="form-control-label">Description<span class="text-danger">*</span></label>
                            <textarea name="content" id="content" class="form-control"><?php echo e($edit->content); ?></textarea>
                        </div> 
                        <div class="form-group">
                            <label for="keyword" class=" form-control-label">keyword <span class="text-danger">(optional)</span></label>
                            <input type="text" id="keyword" value="<?php echo e($edit->keyword); ?>" name="keyword" class="form-control" placeholder="Enter keywords">  
                        </div>  
                        <button type="submit" class="btn btn-info">Submit</button>   
                    </div> 
                </div>
            </div> 
        </div> 
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?> 
<script src="https://cdn.ckeditor.com/4.15.1/standard/ckeditor.js"></script>    
<script src="<?php echo e(asset('assets/js/lib/chosen/chosen.jquery.min.js')); ?>"></script>    
<script>
       CKEDITOR.replace('content', { 
            filebrowserUploadUrl: "<?php echo e(asset('admin/page/uploads?_token=' . csrf_token())); ?>&type=file", 
            imageUploadUrl: "<?php echo e(asset('admin/page/uploads?_token='. csrf_token() )); ?>&type=image",
            filebrowserBrowseUrl: "<?php echo e(asset('admin/page/file_browser')); ?>",
            filebrowserUploadMethod: 'form' 
		}); 
    jQuery("#type").chosen({ 
        no_results_text: "Oops, nothing found!",
        width: "100%"
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\music-website\resources\views/admin/pages/page/edit-page.blade.php ENDPATH**/ ?>
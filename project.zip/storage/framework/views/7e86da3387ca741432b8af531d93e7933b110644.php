
<?php $__env->startSection('title'); ?>
    about-us
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="education-area-two " style="padding: 150px 0px 100px;">
       
        <div class="container">
            <div class="row"> 
                <div class="col-lg-12">
                   <?php if($page): ?>
                        <?php echo $page->content; ?>

                    <?php else: ?>
                        Not found!
                    <?php endif; ?>
                </div> 
            </div> 
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\music-website\resources\views/pages/page/page.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title'); ?>
    Update social and Address information
<?php $__env->stopSection(); ?> 
<?php $__env->startSection('content'); ?>
<div class="content">
    <form action="<?php echo e(route('socialinfo.update')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal"> 
    <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header">
                        Social infos
                        </div>
                        <div class="card-body card-block"> 
                            <input type="hidden" name="id" value="<?php echo e($social_info ? $social_info->id : ''); ?>"/>
                             <div class="form-group pb-3">
                                <div class="d-flex justify-content-between pb-2">
                                    <label for="image" class=" form-control-label">Social</label>
                                    <button type="button" class="btn btn-sm btn-info add-new-social"><i class="fa fa-plus"></i></button>
                                </div>
                                <div class="social">
                                    <div class="list-group">
                                        <?php if(!empty($social_info) && $social_info->social_datas != ""): ?> 
                                            <?php
                                             $socials = json_decode($social_info->social_datas); 
                                            ?>
                                                <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                        <div class="list-group-item d-flex align-items-center">
                                                            <div class="px-1">
                                                                <input value="<?php echo e($key); ?>" type="text" name="icon[]" placeholder="Social icon name" class="form-control">
                                                            </div>
                                                            <div class="px-1">
                                                                <input value="<?php echo e($data); ?>" type="text" name="link[]"  placeholder="Social Link"  class="form-control">
                                                            </div>
                                                            <div class="feature__trash bg-danger text-white p-2"><i class="fa fa-trash"></i></div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <div class="list-group-item d-flex align-items-center">
                                            <div class="px-1">
                                                <input type="text" name="icon[]" placeholder="Social icon name" class="form-control">
                                            </div>
                                            <div class="px-1">
                                                <input type="text" name="link[]"  placeholder="Social Link"  class="form-control">
                                            </div>
                                            <div class="feature__trash bg-danger text-white p-2"><i class="fa fa-trash"></i></div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>  
                        </div> 
                    </div> 
            </div>
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">
                        Address info
                    </div>
                    <div class="card-body card-block">   
                        <div class="form-group pb-3">
                            <div class="d-flex justify-content-between pb-2">
                            <label for="image" class=" form-control-label"> Address info </label>
                            <button type="button" class="btn btn-sm btn-success add-new-address"><i class="fa fa-plus"></i></button>
                            </div>
                            <div class="address">
                                <div class="list-group">
                                        <?php if(!empty($social_info) &&  $social_info->address_datas != ''): ?>
 <?php
                                              $address_datas = json_decode($social_info->address_datas); 
                                            ?>
                                                <?php $__currentLoopData = $address_datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                     <?php
                                                      $da = explode('|##|', $datas) 
                                                     ?>
                                                    <div class="list-group-item d-flex align-items-center">
                                                        <div class="pr-2" style="flex: 1">
                                                                <div class="py-1">
                                                                    <input value="<?php echo e($da[0]); ?>" type="text" name="address_icon[]" placeholder="Enter icon name" class="form-control">
                                                                </div> 
                                                                <div class="py-1">
                                                                    <textarea  name="address_details[]" id="" cols="30" rows="2" class="form-control" placeholder="Enter details"><?php echo e($da[1]); ?></textarea>
                                                                </div> 
                                                        </div>
                                                            <div class="feature__trash bg-danger text-white p-2"><i class="fa fa-trash"></i></div>
                                                        </div> 
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                    <div class="list-group-item d-flex align-items-center">
                                       <div class="pr-2" style="flex: 1">
                                            <div class="py-1">
                                                <input type="text" name="address_icon[]" placeholder="Enter icon name" class="form-control">
                                            </div> 
                                            <div class="py-1">
                                                <textarea name="address_details[]" id="" cols="30" rows="2" class="form-control" placeholder="Enter short details"></textarea>
                                            </div> 
                                       </div>
                                        <div class="feature__trash bg-danger text-white p-2"><i class="fa fa-trash"></i></div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>   
                    </div> 
                </div>  
            </div>
        </div>
             <div class="card">
            <div class="card-body d-flex justify-content-center">
              <button type="submit" class="btn btn-info">Update</button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\music-website\resources\views/admin/pages/social-info/social-info.blade.php ENDPATH**/ ?>
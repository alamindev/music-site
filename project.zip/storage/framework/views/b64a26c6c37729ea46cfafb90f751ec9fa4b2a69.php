

<?php $__env->startSection('content'); ?>
<div class="content">
   <div class="card">
    <div class="card-header">
        Update Setting
    </div>
        <div class="card-body card-block">
            <form action="<?php echo e(route('setting.update')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal"> 
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($setting ? $setting->id : ''); ?>"/>
                <div class="row form-group">
                    <div class="col col-md-3">
                        <label for="site_logo" class=" form-control-label">Site title</label>
                    </div>
                    <div class="col-12 col-md-9">
                        <input type="text" id="site_title" name="site_title" class="form-control" value="<?php echo e($setting ? $setting->site_title : ''); ?>" > 
                        <?php if($errors->has('site_title')): ?>
                            <div class="text-danger"><?php echo e($errors->first('site_title')); ?></div>
                        <?php endif; ?>  
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col col-md-3">
                        <label for="site_logo" class=" form-control-label">Site Logo <span class="text-danger">(Image type must PNG,JPG)</span></label>
                    </div>
                    <div class="col-12 col-md-9">
                        <input type="file" id="site_logo" name="site_logo" class="form-control-file"> 
                        <?php if($errors->has('site_logo')): ?>
                                <div class="alert alert-danger"><?php echo e($errors->first('site_logo')); ?></div>
                            <?php endif; ?>
                            <div  class="py-2">
                        <?php if(!empty($setting) && $setting->site_logo != ''): ?>
                            <img src="<?php echo e(url('storage'.$setting->site_logo)); ?>" alt="site logo" width="100">
                        <?php endif; ?>
                        </div> 
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col col-md-3">
                        <label for="favicon" class=" form-control-label">Favicon <span class="text-danger">(Image type must PNG,JPG)</span></label>
                    </div>
                    <div class="col-12 col-md-9">
                        <input type="file" id="favicon" name="favicon"   class="form-control-file">
                        <?php if($errors->has('favicon')): ?>
                            <div class="alert alert-danger"><?php echo e($errors->first('favicon')); ?></div>
                        <?php endif; ?>
                       <div  class="py-2">
                        <?php if(!empty($setting) && $setting->favicon != ''): ?>
                            <img src="<?php echo e(url('storage'.$setting->favicon)); ?>" alt="Favicon" width="100">
                        <?php endif; ?>
                       </div>
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col col-md-3">
                        <label for="copyright" class="form-control-label">Copyright</label>
                    </div>
                    <div class="col-12 col-md-9">
                        <input type="text" id="copyright" value="<?php echo e($setting ? $setting->copyright : ''); ?>"  name="copyright" class="form-control">
                    </div>
                </div>
                <div class="p-2">
                    <button type="submit" class="btn btn-success btn-sm">
                        <i class="fa fa-dot-circle-o"></i> update
                    </button> 
                </div>
            </form>
        </div> 
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\music-website\resources\views/admin/pages/setting/setting.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title'); ?>
    password reset
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <section class="user-area-style" style="padding: 150px 0px 50px;">
        <section class="user-area-style recover-password-area">
            <div class="container">
                <div class="contact-form-action recover">
                    <div class="form-heading text-center">
                        <h3 class="form-title">Reset Password!</h3>
                        <p class="reset-desc">Enter the Number of your account to reset the password.</a>
                        </p>
                    </div>
                    <?php if(Session::has('message')): ?>
                        <div class="alert alert-danger"><?php echo e(Session::get('message')); ?></div>
                    <?php endif; ?>
                    <form method="post" action="<?php echo e(route('reset-password-post')); ?>">
                    <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <input class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required type="string"  name="phone" placeholder="Enter Number">
                                     <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <a class="now-log-in font-q" href="<?php echo e(route('login')); ?>">Log In in your account</a>
                            </div>

                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <p class="now-register">
                                    Not a member?
                                    <a class="font-q" href="<?php echo e(route('register')); ?>">Registration</a>
                                </p>
                            </div>

                            <div class="col-12">
                                <button class="default-btn btn-two" type="submit">
									Reset Password
								</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\music-website\resources\views/auth/passwords/phone.blade.php ENDPATH**/ ?>
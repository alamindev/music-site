
<?php $__env->startSection('title'); ?>
    banner update
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
   <div class="card">
    <div class="card-header">
        Update Banner
    </div>
        <div class="card-body card-block">
            <form action="<?php echo e(route('banner.update')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal"> 
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($banner ? $banner->id : ''); ?>"/>
                <div class="row form-group">
                    <div class="col col-md-3">
                        <label for="title" class=" form-control-label">Title</label>
                    </div>
                    <div class="col-12 col-md-9">
                        <input type="text" id="title" name="title" class="form-control" value="<?php echo e($banner ? $banner->title : ''); ?>" > 
                        <?php if($errors->has('title')): ?>
                            <div class="text-danger"><?php echo e($errors->first('title')); ?></div>
                        <?php endif; ?>  
                    </div>
                </div> 
                <div class="row form-group">
                    <div class="col col-md-3">
                        <label for="subtitle" class=" form-control-label">Subtitle</label>
                    </div>
                    <div class="col-12 col-md-9">
                        <input type="text" id="subtitle" name="subtitle" class="form-control" value="<?php echo e($banner ? $banner->subtitle : ''); ?>" >  
                    </div>
                </div> 
                <div class="row form-group">
                    <div class="col col-md-3">
                        <label for="details" class=" form-control-label">Details</label>
                    </div>
                    <div class="col-12 col-md-9">
                        <textarea name="details" class="form-control" id="details" cols="30" rows="10">
                        <?php echo e($banner ? $banner->details : ''); ?>

                        </textarea> 
                    </div>
                </div>
             <div class="row form-group">
                    <div class="col col-md-3">
                        <label for="image" class=" form-control-label">Banner image </label>
                    </div>
                    <div class="col-12 col-md-9">
                        <input type="file" id="image" name="image" class="form-control-file">  
                        <div  class="py-2">
                        <?php if(!empty($banner) && $banner->image != ''): ?>
                            <img src="<?php echo e(url('storage'.$banner->image)); ?>" alt="Banner image" width="100">
                        <?php endif; ?>
                        </div> 
                    </div>
                </div>
                 <div class="row form-group">
                    <div class="col col-md-3">
                        <label for="btn_text" class=" form-control-label">Button Text</label>
                    </div>
                    <div class="col-12 col-md-9">
                        <input type="text" id="btn_text" name="btn_text" class="form-control" value="<?php echo e($banner ? $banner->btn_text : ''); ?>" >  
                    </div>
                </div> 
                 <div class="row form-group">
                    <div class="col col-md-3">
                        <label for="btn_link" class=" form-control-label">Button Link</label>
                    </div>
                    <div class="col-12 col-md-9">
                        <input type="text" id="btn_link" name="btn_link" class="form-control" value="<?php echo e($banner ? $banner->btn_link : ''); ?>" >  
                    </div>
                </div> 
                <div class="p-2">
                    <button type="submit" class="btn btn-success btn-sm">
                        <i class="fa fa-dot-circle-o"></i> update
                    </button> 
                </div>
            </form>
        </div> 
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\music-website\resources\views/admin/pages/banner/banner.blade.php ENDPATH**/ ?>
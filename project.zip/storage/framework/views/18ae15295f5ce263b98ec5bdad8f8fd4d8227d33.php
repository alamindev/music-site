

<?php $__env->startSection('title'); ?>
Import data
<?php $__env->stopSection(); ?> 
<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="row">
  <div class="col-lg-6 offset-lg-3">
     <div class="card">
    <div class="card-header">
      Add new instrument   
    </div>
        <div class="card-body card-block">
            <form action="<?php echo e(route('import.store')); ?>" method="post"   class="form-horizontal" enctype="multipart/form-data"> 
                <?php echo csrf_field(); ?> 
                <div class="form-group">
                    <label for="file" class=" form-control-label">Select File<span class="text-danger">*</span></label>
                        <input type="file" id="file" name="file" class="form-control"> 
                    <?php if($errors->has('file')): ?>
                        <div class="text-danger"><?php echo e($errors->first('file')); ?></div>
                    <?php endif; ?>   
                </div>   
                <div class="p-2">
                    <button type="submit" class="btn btn-success btn-sm">
                       <i class="fa fa-plus"></i> Save
                    </button> 
                </div>
            </form>
        </div> 
    </div>
  </div> 
  </div>
</div>
 
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\music-website\resources\views/admin/pages/import/import.blade.php ENDPATH**/ ?>
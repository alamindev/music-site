
<?php $__env->startSection('title'); ?>
    Exercise
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="courses-area-style " style="padding: 100px 0px;">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <?php if(!empty($exercise)): ?>
                       <div class="embed-responsive embed-responsive-16by9"> 
                            <iframe  id="frame" class="embed-responsive-item" src="<?php echo e($exercise->url); ?>"></iframe>  
                        </div>
                    <?php else: ?>
                        Not found! try again
                    <?php endif; ?>
                </div> 
            </div>
            <div class="row">
                <div class="col-lg-4">
                    <div class="d-flex justify-content-start pt-5">
                        <form action="<?php echo e(route('step.viewer')); ?>" method="get"> 
                            <?php if(!empty($previous)): ?>
                            <input type="hidden" name="exercise_id" value="<?php echo e($previous->exercise_id); ?>">
                            <input type="hidden" name="instrument_id" value="<?php echo e($previous->horn_id); ?>">
                            <input type="hidden" name="book_id" value="<?php echo e(app('request')->input('book_id')); ?>">
                            <?php endif; ?>
                             <button <?php if(!$previous): ?> disabled <?php endif; ?>  type="submit" class="btn btn-success">Previous</button>
                        </form> 
                    </div>
                </div>
                <div class="col-lg-4">
                     <div class="d-flex justify-content-center pt-5">
                        <form action="<?php echo e(route('step.completed')); ?>" method="post">
                            <?php echo csrf_field(); ?>  
                            <input type="hidden" class="timer" name="time" value="00:00" >
                            <input type="hidden" name="url_id" value="<?php echo e($exercise->id); ?>">
                            <button type="submit" class="btn btn-success">  Completed</button>
                        </form>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="d-flex justify-content-end pt-5">
                        <form action="<?php echo e(route('step.viewer')); ?>" method="get"> 
                             <?php if(!empty($next)): ?>
                            <input type="hidden" name="exercise_id" value="<?php echo e($next->exercise_id); ?>">
                            <input type="hidden" name="instrument_id" value="<?php echo e($next->horn_id); ?>">
                            <input type="hidden" name="book_id" value="<?php echo e(app('request')->input('book_id')); ?>">
                            <?php endif; ?>   
                             <button <?php if(!$next): ?> disabled <?php endif; ?>  type="submit" class="btn btn-success">Next</button>
                        </form> 
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>  
 
<?php $__env->startSection('script'); ?>

<script>
    $(function (){
        var timer = $(".timer"); 
        var totalSeconds = 0; 
        setInterval(setTime, 1000);

        function setTime() {
            ++totalSeconds;
            timer.val(pad(parseInt(totalSeconds / 60)) + " : " + pad(totalSeconds % 60)) 
        }

        function pad(val) {
        var valString = val + "";
        if (valString.length < 2) {
            return "0" + valString;
        } else {
            return valString;
        }
        }
    })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\music-website\resources\views/pages/step/viewer.blade.php ENDPATH**/ ?>